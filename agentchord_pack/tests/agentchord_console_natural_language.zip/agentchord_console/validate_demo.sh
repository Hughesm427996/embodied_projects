#!/usr/bin/env bash
set -euo pipefail
script_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
project_dir="$(cd -- "$script_dir/.." && pwd)"
if [[ ! -x "$project_dir/.venv/bin/python" ]]; then
  echo "请把 agentchord_console 文件夹放到已经跑通的 AgentChord-sim 项目里面。"
  exit 1
fi
cd -- "$project_dir"
# This validation uses the saved DeepSeek key and the official default endpoint.
exec env -u DEEPSEEK_API_KEY -u OPENAI_API_KEY -u LLM_URL \
  "$project_dir/.venv/bin/python" "$script_dir/validate_demo.py" "$@"
