# AgentChord 自然语言桌面整理控制台

直接用自然语言描述目标，由 DeepSeek 解释对象、位置及“不动某件餐具”等限制。本地程序将校验后的目标编成已支持的机器人技能，检查完整动作后，交给原 AgentChord 图运行器和 DexSim 执行。无需记固定任务指令。

## 安装与启动

将 agentchord_console_saved_key.zip 传到 Ubuntu 的项目目录：

    /home/xiaoyu/embodied_projects/AgentChord-sim

退出旧控制台，然后执行：

    cd "$HOME/embodied_projects/AgentChord-sim"
    python3 -m zipfile -e agentchord_console_saved_key.zip .
    bash agentchord_console/start.sh --no-proxy --stable-scene --seed 0

使用已经跑通的 .venv、原项目代码、机器人资源及此前 CUDA 修复。没有新增依赖。默认物理 GPU 0、640×480 录像、种子 0。--stable-scene 关闭初始餐具及机械臂姿态随机化，方便先验证演示。--no-proxy 仅让本轮子进程忽略代理环境变量，需机器可以直连 DeepSeek。

DeepSeek API 密钥可以只配置一次。运行下列命令，在提示后粘贴密钥并回车；输入不会显示，也不会进入 shell 命令历史：

    bash agentchord_console/start.sh --save-api-key

保存成功后，再按上面的普通命令启动。密钥单独保存为 ~/.config/agentchord_console/deepseek_api_key（设置了绝对路径 XDG_CONFIG_HOME 时使用该目录），配置目录权限 700、文件权限 600。该文件是本机明文配置，仅当前用户可读写，不在项目、日志或脚本 ZIP 内。不要将它作为实验结果发送。更新密钥时重复配置命令；取消保存时删除该文件。

读取顺序为 DEEPSEEK_API_KEY 环境变量、OPENAI_API_KEY 环境变量、本地配置文件。如果三者都没有，仍会隐藏询问，且仅保留在本次启动期间。不需要把密钥写进 .bashrc。默认使用已测试的 deepseek-flash、https://api.deepseek.com。

## 自然说话

可以直接输入，例如：

- 帮我整理一下餐盘，把餐具放进去。
- 只把勺子放盘里，叉子别动。
- 叉子放在餐盘左边，勺子放右边。
- 把叉子往右挪五厘米。
- 能不能帮我把两个餐具摆好？

这些是表达示例，不是匹配词表。每条任务文本都真实调用 DeepSeek JSON mode，由模型按句意解析。先打印公开的理解摘要和默认约定，再检查并执行。模型可能误解，因此请核对摘要和录像；这不是对所有表达都理解准确的保证。

需要补充对象或位置时，模型会问一个具体问题。在下一次“指令 >”直接回答，例如“勺子”“放盘子里面”。对话保留最近四轮供指代和澄清使用。普通问答、模型要求补充或识别出未支持任务时，不启动仿真；动作布局检查阶段也可能要求分开重合目标，此时场景已初始化，但不会操作餐具。

每条执行指令都会从初始场景开始新一轮。对话上下文用于理解语言，不代表沿用上一轮的物理状态。“往右挪五厘米”以本轮初始位置为基准，会在默认说明中告知；目前不能在前一轮结果上继续操作或撤销上轮物理动作。

录像结束时保留窗口。可以直接在终端输入下一条自然语言要求，也可以按回车回到控制台；输入的下一条要求会被接收，不再丢弃。

## 当前能够操作什么

当前场景为盘子、叉子、勺子和双机械臂。可以搬运一件或两件餐具，放在盘内、盘旁，或按明确的水平偏移移动。盘子用作位置参照。没有杯子、抹布等物体，也没有搬盘子、擦桌子、指定餐具旋转或恢复实验技能。模型会说明缺少的能力；不会把包含未支持部分的请求悄悄裁成另一项任务来执行。

未指定坐标系时，“左右、前后”按本轮录像相机视角。程序从相机 eye/target 计算方向；默认视角画面右为世界 +Y，画面前为世界 +X。用户明确世界 X/Y 或数值时按指定轴换算，单位为米，单轴最多 ±0.30 米。

“整理餐盘”等普通整理请求默认两件餐具分开放入盘内，模型会说明此默认。只要求某件餐具时，仅给相应臂下达动作；另一臂保持其当前姿态。物理接触仍可能影响其他物体，应通过视频和最终坐标确认限制是否落实。

## 动作如何执行

通过校验的语义目标转换为抓取 → 朝下 → 悬停 → 下放 → 释放 → 返回初始姿态六步图。对象分配沿用叉子对应 left_arm、勺子对应 right_arm。第一版仍使用已验证的技能流程；机器人手臂名称与画面左右无关。

执行前检查首步精确抓取 IK 和整段原 SDK 动作/轨迹，在独立的代理状态副本上预检，不调用 drive 或 env.step。遇到原 IK 返回 false 时，只测试有限候选。用户明确的水平坐标和方位不改；未指定的盘内间距、悬停/释放高度可选不同候选。原生轨迹异常不当作不可达继续重试。跳过检查或候选全部失败时停止餐具操作，并保存诊断。

预检通过仅说明关键姿态和轨迹可生成。是否实际抓住、碰撞、滑落以及餐具是否完整放在盘内，仍需物理仿真视频核验。此前的两侧摆放指标 y±0.16 米不用于判定盘内或其他自定义目标成功；它保留在 result.json 中。

Toppra 插值入口临时使用 CPU 关节数值，IK 与物理仿真仍在 cuda:0。只在当前进程内包装，结束时恢复，原 SDK 文件不修改。此前 finalize_actions 和轨迹输出的 CUDA→NumPy 修复需要保留，单臂 idle 分支也依赖它们。

## 控制台命令

- 视频：打开最近一轮实际仿真录像；问答不会覆盖它。
- 结果：显示最近一轮仿真目录。
- 重新规划 [要求]：重新解释并规划要求；自然语言模式每条要求都会调用 API。
- 退出：结束控制台。整理过程中可按 Ctrl+C 停止当前进程。

一条命令执行：

    bash agentchord_console/start.sh --no-proxy --stable-scene --instruction "只把勺子放盘里，叉子别动"

默认已经是自然语言模式。旧 --plate-layout 参数在此模式下不限制文本；布局根据语义自动选择。

需要回到旧版的原 TaskAgent 图生成流程，可加 --legacy-plan；旧版固定双餐具盘内演示可同时加 --legacy-plan --plate-layout。旧基线缓存保留。

## 记录与核验

每轮放在 outputs/command_console/日期时间/，包括：

- intent.json：模型解释后的、经过校验的公开目标。不读取或保存内部 reasoning_content。
- run.json：原话、模型、场景配置、视角约定和最近对话上下文；密钥不写入。
- task_plan.json、agent_compiled_graph.language.json：本地技能编排和目标图。
- plan_check.json、grasp_check.json：完整候选检查和首步抓取检查。
- agent_compiled_graph.original.json、agent_compiled_graph.used.json、plan_summary.json：原输入工作图、实际执行图和公开动作摘要。
- planning_trace.json、run.log：阶段记录与日志。
- initial.png、final.png、videos/episode_0_cam1.mp4：仿真初末截图和录像，发生普通 Python 异常时也尽量保存结束状态。
- result.json：理解类别、执行是否完成、餐具初末坐标、原场景指标和视频路径；动作完成不等于实际摆放合格。
- process_status.json：退出码。

问答与模型澄清只保存理解/回复和日志，没有视频是正常情况。API 错误或 JSON 格式错误会停止本轮；不会执行模型生成的任意 Python 或 shell 代码。

已完成本地假 SDK、语义 schema、方位转换、单/双对象图、上下文、失败停止、原校验器和执行次数验证。此前固定双餐具摆盘已经在 2080 完成 220 步并导出视频；新的自然语言调用和单臂流程仍需这台 2080 实测。若报错，发送 run.log、intent.json、plan_check.json、result.json 中已生成的文件；若动作跑完，发送 MP4 和 result.json。

参考：[AgentChord](https://github.com/EDEM-AI/AgentChord)、[DeepSeek JSON Output](https://api-docs.deepseek.com/guides/json_mode/)。
