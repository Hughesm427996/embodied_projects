# AgentChord Ubuntu 桌面整理控制台

在实验室 Ubuntu 图形桌面的终端输入指令，运行真实 AgentChord / DexSim 桌面仿真。每轮生成独立的视频、日志与初末截图，结束后保留最后画面，按回车回到指令输入。

## 放到哪里

需要你已经跑通的项目：

    /home/xiaoyu/embodied_projects/AgentChord-sim

你发来的 normal_20261009_200658 文件夹包含 episode_0_cam1.mp4 和运行日志，是参考结果。运行脚本需要原项目代码、.venv、机器人资源和此前修复；本包使用它们。

把 agentchord_console_plate_layout.zip 从本机传到 Ubuntu 的上述项目目录，然后在 Ubuntu 终端执行：

    cd "$HOME/embodied_projects/AgentChord-sim"
    python3 -m zipfile -e agentchord_console_plate_layout.zip .
    bash agentchord_console/start.sh

解压后的结构是 AgentChord-sim/agentchord_console/console.py、grasp_check.py、plan_check.py、plate_plan.py、start.sh、README.md。

请在有仿真窗口的 Ubuntu 图形桌面终端运行。脚本固定使用物理 GPU 0，与已跑通的配置一致。启动前若曾设置 CUDA_VISIBLE_DEVICES，执行 unset CUDA_VISIBLE_DEVICES，避免设备编号重映射。

## 第一轮

输入：

    整理桌子

如果终端里还没有 API 密钥，脚本会让你隐藏输入 DeepSeek API 密钥，只在本次进程内使用。不要把密钥发到聊天里。默认使用 https://api.deepseek.com 与 deepseek-flash，沿用你已经测试过的服务。

“整理桌子”优先复用项目中 Rearrangement_DS_Normal 的已有任务计划；它仍会重新运行物理仿真，并记录新视频。如果缓存不存在，就调用 API 生成计划。

完成时会显示录像路径，并保留仿真的结束画面。在终端按回车，回到“指令 >”。随后输入：

    视频

会尝试用 Ubuntu 默认播放器打开本轮录像；没有播放器时可直接在文件管理器打开显示的 MP4。

## 规划说明与执行过程

默认开启。终端会依次显示目标、初始场景、计划来源、左右臂动作计划、执行阶段和结果。动作顺序沿本轮实际图的 start → goal 路径提取；打印的“计划目标”是预期状态。原项目的轨迹进度日志仍会实时显示。

这是可核对的任务规划摘要，不包含模型内部思维链，也不额外调用 API 来生成解释。只有结果检查和视频能确认实际摆放效果。

每轮会另外保存 planning_trace.json（阶段及时间）和 plan_summary.json（本轮实际计划摘要）。在 Ubuntu 文本编辑器中打开，或使用 python3 -m json.tool 查看。

## 可输入的内容

- 整理桌子：执行原来的盘子两侧餐具整理任务。
- 重新规划 整理桌子：让 DeepSeek 重新生成计划，使用独立缓存，保留原来的任务缓存。
- 具体要求，例如“把叉子和勺子分别摆在盘子两侧，并松开夹爪”：将文字传给项目原 TaskAgent，生成并执行对应计划。新指令的执行效果需要看视频核验。
- 视频：打开最近一轮录像。
- 结果：打印最近一轮结果目录。
- 退出：退出控制台。

当前场景是双机械臂、桌子、盘子、叉子和勺子；请围绕现有物体下指令。每次输入执行一轮，过程中需要停止时在终端按 Ctrl+C。本版用于正常整理流程，未启用扰动注入或恢复对照。

## 保存的结果

每轮结果单独放在：

    AgentChord-sim/outputs/command_console/日期时间/

包括：

- videos/episode_0_cam1.mp4：默认 640×480、20 fps，执行录像。
- initial.png、final.png：同一录像相机的开始和结束画面。
- run.log：完整运行日志，API 密钥做脱敏处理。
- planning_trace.json：目标、规划来源、执行阶段和结果的时间记录。
- plan_summary.json：本轮实际左右臂动作计划摘要（计划图可读取时）。
- agent_compiled_graph.original.json、agent_compiled_graph.used.json：原始图与实际使用的图。
- graph_correction.json：终点校正及经过 IK 检查的抓取接近距离调整（有调整时）。
- grasp_check.json：首步抓取可达性检查与选用参数。
- run.json：输入指令、模型、配置路径、缓存任务名。
- gym_config.json、agent_config.snapshot.json：本轮配置快照。
- agent_task_graph.json、agent_compiled_graph.json：本轮实际使用的计划快照（如项目产出）。
- result.json：动作执行状态、原场景判定、物体初末坐标、视频路径或报错。
- process_status.json：进程退出码。

“动作执行完成”表示计划执行到了结束。原场景成功判定只检查叉子/勺子相对盘子的 y 位置（±0.16 米，容差 0.02 米），没有检查高度、朝向或是否稳放桌面。判断整理效果时请结合视频、结束截图和物体坐标；自定义目标也可能不符合这个原始判定。

脚本不在结束后 reset，因此结束截图和保留的画面来自本轮实际执行结果。原场景初始姿态包含随机项，多轮画面可能有差异。

## 抓取前可达性检查与稳定场景

默认对首条边中的 grasp 做精确 IK 预检。它读取本轮实际物体姿态和机械臂状态，不执行物理步进、不改变代理关节状态。先检查计划中的接近距离；若预抓取或实际抓取没有解，依次检查不大于原距离的 0.05 米、0.03 米。只有两个姿态均有解，才将所选距离写到本轮工作图。左右臂分配、物体目标、原始缓存保持原样。

每轮保存 grasp_check.json，包含候选距离、预抓取/抓取 IK 返回值、目标矩阵、基座矩阵及关节种子。候选全部失败时停止本轮，并保存这份诊断；不会自动启用 force_valid 或把抓取目标换成附近的点。预检只说明姿态可解，实际是否抓住仍需看录像。

默认种子为 0，同时写入 env cfg 和 reset。种子有助于重复同一初始化，物理仿真仍可能有数值差异。需要先测试固定初始姿态演示时：

    bash agentchord_console/start.sh --no-proxy --stable-scene --seed 0

--stable-scene 仅去掉叉子/勺子位姿和机械臂初始末端随机化事件，保留抓取属性、注册信息和物理初始化。其结果记录 stable_scene=true，是固定场景演示条件。

想保留姿态随机化，去掉 --stable-scene；想跳过首步 IK 预检，使用 --skip-grasp-check。若初始状态不符合预检条件（例如夹爪关闭、姿态已改变或 force_valid=true），会显示跳过原因，执行原流程。

## 终点返回动作的图错误

若规划器把返回动作写成 goal → goal 自环，或将 goal 提前设在连续返回动作之前，本版会检查完整拓扑。在唯一、连续的路径且额外动作均为 back_to_initial_pose、恢复绑定为空时，校正执行工作副本的终点；保留每个动作函数和参数，原任务缓存保持原样。分支、其他循环、断开的边、重复 ID 或恢复配置不会自动修复。原项目验证器仍会检查实际执行图。

每轮保存 agent_compiled_graph.original.json（原图）、agent_compiled_graph.used.json（实际执行图）；发生校正时保存 graph_correction.json（差异）。plan_summary.json 对应实际执行图。

如果计划让左右臂对同一物体使用相同位置偏移，终端会显示提示。这类物理摆放问题需要视频核验，拓扑修复保持原动作参数。


## 叉子和勺子放入盘内的演示

你发来的固定场景日志已经显示：两臂精确抓取 IK 均通过，实际执行了 75 步抓取；接着左臂移向盘上方时没有 IK 解。那份计划让两臂目标同为 plate+(0,0,0.15)，抓取后没有独立调整末端朝向。

本版增加一个显式下层摆放选项，先用它验证一轮：

    bash agentchord_console/start.sh --no-proxy --stable-scene --seed 0 --plate-layout

然后输入：

    将叉子和勺子放在餐盘里面

此选项仅适用于这两个现有餐具的盘内任务。它仍读取 DeepSeek 生成或缓存的任务图，保留首步左臂抓叉子、右臂抓勺子的参数；后面的机器人动作由本地摆放模板细化。因此这是“API 任务计划＋显式本地下层布局”的演示条件。原始计划保持在缓存及 agent_compiled_graph.original.json；实际执行工作图与每项调整另存。

六步流程为：双臂抓取 → 末端朝下 → 分开移到盘子上方 → 降低到释放位置 → 松开夹爪 → 向上撤离并返回初始姿态。默认左右末端世界 y 偏移分别 +0.06/-0.06 米，悬停 z 偏移 0.08 米，释放 z 偏移 0.025 米。这些数值是夹爪末端相对盘子原点的世界坐标偏移，尚不保证餐具整体位于盘内。

执行前，在机械臂代理状态的独立副本上调用原 SDK 的原子动作，生成整段 IK 及轨迹，不调用 drive、env.step、物体设置或仿真步进。仅代理真实场景的只读物体姿态、IK、FK 与机器人 uid；三个状态 getter/setter 显式作用在副本。它只支持首步抓取、此后的 stationary plate 移动和已核查的朝向/释放/返回技能。恢复配置、真实后端、感知覆盖及不匹配任务会停止此模式，避免将跳过检查视为通过。

原 SDK 的 Toppra 输入阶段存在将 CUDA 关节点直接交给 NumPy 的分支。本轮会临时把轨迹插值入口的关节点复制至 CPU，保持关节数值、机器人设备、采样参数和夹爪状态。IK 与实际仿真仍在 cuda:0；结束时恢复原接口，不修改项目源文件。此前 CUDA→NumPy 输出端修复仍需保留。

如果某个姿态的原 IK 返回失败，最多检查六个明确候选布局（y 分离 0.04/0.06/0.08 米、悬停 0.06/0.08/0.10 米、释放 0.025/0.035 米的预设组合）。原生轨迹/后端异常不会当作不可达继续搜索。完整候选通过才执行；都失败时保存诊断，不执行物理动作，也不启用 force_valid 或改成盘外目标。

每轮另外保存 plan_check.json，含各候选的动作、轨迹步数、每次 IK 目标和关节种子，以及失败边/机械臂。检查通过只表示关键姿态和轨迹可以生成，碰撞、实际夹持、滑落及最终摆放仍由物理仿真和录像验证。本版在普通 Python 异常退出时也保存 final.png、final_objects、已有视频与图路径，方便判断停止在哪一步。原来的 y±0.16 成功指标不适用于盘内目标。

需要自由文字规划或原来的盘子两侧整理，去掉 --plate-layout。该选项本身不启用扰动注入或恢复对照。

## 代理地址报错时

如果 ChatOpenAI 提示 Unknown scheme socks://，可以让本次仿真直接访问 DeepSeek：

    bash agentchord_console/start.sh --no-proxy

这个选项只移除仿真子进程的 HTTP_PROXY、HTTPS_PROXY、ALL_PROXY 及小写形式，保留启动它的终端环境。要求该 Ubuntu 机器能直接连到 DeepSeek。

如果必须通过 SOCKS 代理联网，需要确认该端口支持 SOCKS5，使用 socks5:// 地址，并在项目 .venv 内安装 socksio。不要把纯 SOCKS 端口改成 http://；HTTP 代理地址必须对应服务真实提供的 HTTP 端口。

HTTPX 官方说明：https://www.python-httpx.org/advanced/proxies/

## 一条命令运行

    bash agentchord_console/start.sh --instruction "整理桌子"

需要完成后自动关闭仿真窗口：

    bash agentchord_console/start.sh --instruction "整理桌子" --no-hold

需要沿用原视频大小：

    bash agentchord_console/start.sh --resolution 320 240

也可以显式指定项目位置：

    .venv/bin/python agentchord_console/console.py --project "$HOME/embodied_projects/AgentChord-sim"

## 已验证范围

已通过 Python 语法检查和本地模拟测试：指令传递、缓存隔离、相机尺寸与内参同步、日志密钥脱敏、单条指令退出、录像导出与等待回车顺序、失败时清理、计划拓扑排序、执行前显示计划、无效图提前停止、代理环境隔离、默认代理保留、终点返回自环校正、前置终点校正、缓存保持和异常拓扑拒绝、稳定场景的事件过滤、精确 IK 候选选择、种子传递、不执行物理步进及预检失败时停止。已按固定版本 74fe7dd756964b737952d26e9e65d4d5e2e29ec3 的官方接口核查。

此前的抓取检查版本已在实验室 2080 上通过初始化、首步 IK 与 75 步抓取执行，且成功导出失败前视频。本次新增整段检查、盘内布局和 CPU 插值输入包装尚待这台 2080 实测。若报错，发送新一轮 plan_check.json、result.json；若已完成，发送 MP4 和 result.json 核验摆放效果。

参考仓库：https://github.com/EDEM-AI/AgentChord
